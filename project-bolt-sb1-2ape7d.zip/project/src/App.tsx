import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { PasswordInput } from './components/PasswordInput';
import { StrengthIndicator } from './components/StrengthIndicator';
import { checkPasswordStrength } from './utils/passwordStrength';

function App() {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const strengthResult = checkPasswordStrength(password);

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md space-y-6">
        <div className="flex items-center gap-3">
          <Shield className="text-blue-500" size={24} />
          <h1 className="text-2xl font-bold text-gray-800">Password Strength Checker</h1>
        </div>

        <div className="space-y-4">
          <PasswordInput
            password={password}
            onChange={setPassword}
            showPassword={showPassword}
            onToggleVisibility={() => setShowPassword(!showPassword)}
          />

          {password && <StrengthIndicator strengthResult={strengthResult} />}
        </div>
      </div>
    </div>
  );
}

export default App;