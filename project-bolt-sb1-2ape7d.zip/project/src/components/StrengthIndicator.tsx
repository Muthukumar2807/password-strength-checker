import React from 'react';
import { Check, X } from 'lucide-react';
import type { PasswordCriteria, StrengthResult } from '../utils/passwordStrength';

interface StrengthIndicatorProps {
  strengthResult: StrengthResult;
}

const CriteriaItem: React.FC<{ label: string; met: boolean }> = ({ label, met }) => (
  <div className="flex items-center gap-2">
    {met ? (
      <Check className="text-green-500" size={16} />
    ) : (
      <X className="text-red-500" size={16} />
    )}
    <span className={met ? 'text-green-500' : 'text-red-500'}>{label}</span>
  </div>
);

export const StrengthIndicator: React.FC<StrengthIndicatorProps> = ({ strengthResult }) => {
  const { score, criteria, message, color } = strengthResult;

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className={`font-semibold ${color}`}>{message}</span>
          <span className={`font-semibold ${color}`}>{score}%</span>
        </div>
        <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-300 ${color.replace('text', 'bg')}`}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
        <CriteriaItem label="At least 8 characters" met={criteria.isLongEnough} />
        <CriteriaItem label="Lowercase letter" met={criteria.hasLowerCase} />
        <CriteriaItem label="Uppercase letter" met={criteria.hasUpperCase} />
        <CriteriaItem label="Number" met={criteria.hasNumber} />
        <CriteriaItem label="Special character" met={criteria.hasSpecialChar} />
      </div>
    </div>
  );
};