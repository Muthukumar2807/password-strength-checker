// Password strength criteria and scoring
export interface PasswordCriteria {
  hasLowerCase: boolean;
  hasUpperCase: boolean;
  hasNumber: boolean;
  hasSpecialChar: boolean;
  isLongEnough: boolean;
}

export interface StrengthResult {
  score: number;
  criteria: PasswordCriteria;
  message: string;
  color: string;
}

export const checkPasswordStrength = (password: string): StrengthResult => {
  const criteria: PasswordCriteria = {
    hasLowerCase: /[a-z]/.test(password),
    hasUpperCase: /[A-Z]/.test(password),
    hasNumber: /\d/.test(password),
    hasSpecialChar: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    isLongEnough: password.length >= 8,
  };

  // Calculate score based on criteria
  let score = 0;
  Object.values(criteria).forEach((isValid) => {
    if (isValid) score += 20;
  });

  // Determine message and color based on score
  const getMessageAndColor = (score: number): { message: string; color: string } => {
    if (score <= 20) return { message: 'Very Weak', color: 'text-red-600' };
    if (score <= 40) return { message: 'Weak', color: 'text-orange-500' };
    if (score <= 60) return { message: 'Medium', color: 'text-yellow-500' };
    if (score <= 80) return { message: 'Strong', color: 'text-blue-500' };
    return { message: 'Very Strong', color: 'text-green-600' };
  };

  const { message, color } = getMessageAndColor(score);

  return {
    score,
    criteria,
    message,
    color,
  };
};